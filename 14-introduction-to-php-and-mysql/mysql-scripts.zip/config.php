<?php
	$dbhost = "host";
	$dbuser = "user";
	$dbpass = "password";
	$dbname = "datbase";
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>