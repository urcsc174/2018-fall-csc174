/* replace the dashes below with your first initial, last name e.g. rkostin_phonebook */
CREATE TABLE `---------_phonebook` (
`id` int(11) NOT NULL auto_increment,
`firstname` varchar(32) NOT NULL,
`lastname` varchar(32) NOT NULL,
`phone` varchar(32) NOT NULL,
`email` varchar(32) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;